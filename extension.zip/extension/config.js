// ═══════════════════════════════════════════════════════════════════════════════
// Leedz Extension - Configuration
// ═══════════════════════════════════════════════════════════════════════════════
// تم توليد هذا الملف تلقائياً من .env.master
// لا تعدّل هذا الملف مباشرة - عدّل .env.master وشغّل sync-and-start.ps1
// ═══════════════════════════════════════════════════════════════════════════════

var LEEDZ_CONFIG = {
  // URLs
  API_URL: 'http://192.168.20.16:3001',
  WEB_URL: 'http://192.168.20.16:3000',
  
  // Ports
  API_PORT: 3001,
  WEB_PORT: 3000,
  
  // Extension Settings
  DEBUG_MODE: false,
  SHOW_SEARCH_WINDOW: false,
  MATCH_THRESHOLD: 90
};

// للاستخدام في background.js و sidepanel.js
if (typeof module !== 'undefined' && module.exports) {
  module.exports = LEEDZ_CONFIG;
}
