# Leedz Chrome Extension

إضافة Chrome لمنصة ليدز - تتصل بالـ API الرئيسي على `localhost:3001`

## التثبيت (Development)

1. **تأكد من تشغيل API Server:**
   ```bash
   cd d:\projects\leedz\api
   npm run dev
   ```

2. **أنشئ مجلد الأيقونات:**
   - أنشئ مجلد `icons` داخل `extension`
   - أضف أيقونات: `icon16.png`, `icon32.png`, `icon48.png`, `icon128.png`
   - أو استخدم أيقونات مؤقتة (انظر أدناه)

3. **حمّل الإضافة في Chrome:**
   - افتح `chrome://extensions`
   - فعّل **Developer mode**
   - اضغط **Load unpacked**
   - اختر مجلد `d:\projects\leedz\extension`

4. **استخدم الإضافة:**
   - اضغط على أيقونة الإضافة لفتح Side Panel
   - سجل دخول بنفس بيانات حسابك في المنصة
   - مثال: `admin@optarget.com` / `Admin123!`

## الملفات

| الملف | الوصف |
|-------|-------|
| `manifest.json` | إعدادات الإضافة (MV3) |
| `background.js` | Service Worker - يدير الاتصال بالـ API |
| `sidepanel.html` | واجهة المستخدم |
| `sidepanel.js` | منطق الواجهة |

## الميزات الحالية

- ✅ تسجيل الدخول بنفس بيانات المنصة
- ✅ حفظ الجلسة في `chrome.storage.local`
- ✅ عرض الصفحة الحالية
- 🚧 بحث Google Maps (قيد التطوير)
- 🚧 تحليل الصفحات (قيد التطوير)
- 🚧 إرسال WhatsApp (قيد التطوير)

## إنشاء أيقونات مؤقتة

إذا لم تكن لديك أيقونات، يمكنك إنشاء ملفات PNG فارغة مؤقتاً:

```powershell
# في PowerShell
cd d:\projects\leedz\extension
mkdir icons -Force
# ثم أنشئ صور PNG بسيطة بأي برنامج تحرير صور
```

أو استخدم أي أيقونة PNG مؤقتة بالأحجام المطلوبة.

## API Base URL

الإضافة تتصل بـ: `http://localhost:3001`

يمكن تغييره في `background.js`:
```javascript
const API_BASE = 'http://localhost:3001';
```
